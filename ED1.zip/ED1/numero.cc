//Mostrar os digitos que não aparecem em um inteiro
#include <stdio.h>
#include <stdlib.h>

int main()
{	


	int n = 2190283;
	int p, d;

	for (p = 0; (p < log10(i)); p++)
	{
		d = ((int)i/pow(10,p))%10;
		printf("%d\n", );
	}

	return(0);

	/*
	for (; (i); i /= 10)
	{	d = i%10;
	}
	*/

}