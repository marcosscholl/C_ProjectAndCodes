//mmc

#include <stdio.h>
#include <stdlib.h>

int main()
{
	int n1 = 34, n2 = 16;
	int m1 = n1, m2 = n2;
	int d;

	while (m1 != m2)
	{	if (m1 < m2) m1 += n1;
		else m2 += n2;

	}	
	printf("%d\n", m1 );

	return(0);

}
/*
12 14
24 14
24 28
36 28
36 42
48 42
48 56
60 56
60 70
72 70
72 84
84 84
*/