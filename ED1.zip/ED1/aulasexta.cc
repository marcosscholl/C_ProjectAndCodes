//leitura do teclado

int a;
float b;
char c;
printf("meu texto, var1: %d, var2: %f, var3: %c\n", a,b,c );

scanf("%d", &a); //Le 1 inteiro
scanf("%f", &f); //Le 1 float
scanf("%c", &c); //Le 1 char

int d, m,a;
scanf("%d/%d/%d/", &d, &m, &a); //"1/2/1980"
// Tipos basicos tem & na frente!


//Vetores Matrizes e String estáticas
int v[5]; //Valor inicial do vetor 0;
//Indices v[0],v[1],v[2],v[3],v[4]

//Matriz estatica
float m[3][2]; // 
/*
m[0][0] m[0][1] 
m[1][0] m[1][1] 
m[2][0] m[2][1]
*/

char c [5]; // 
/*
c[0] = 10
c[1] = 15
c[2] = -15
c[3] = 120
c[4] = -120
*/

printf("Digite uma String");
scanf("%s", s);
printf("A string eh: %s\n", s);

//Lendo String caracter a caracter
char w[5], i;
for (i = 0; i < 5; i++) scanf("%c", &w[i]);

for (i = 0; i < 5; i++) printf("%c", w[i]);

char w[5 +1];
scanf("%s", w);
printf("%s", w);

"abc" = { 'a', 'b', 'c', '\o'/*0*/};
('\0' == 0) != ('0' == 48)

//Cabe em w? 

"abc" = { 'a', 'b', 'c', 0}; sim
"abcd" = { 'a', 'b', 'c', 'd', 0}; sim
"abcde" = { 'a', 'b', 'c', 'd', 'e', 0}; //nao precisa de 6 posicoes no vetor q é de 5

char q [50+1];
scanf("%s", q); //"betito"
scanf("%s", q); //"abc"

q[0] == 'a'
q[1] == 'b'
q[2] == 'c'
q[3] == '\0'
q[4] == 't'

printf("%s",q); //"abc"
