//Mudar para maisculo
#include <stdio.h>
#include <stdlib.h>
int main()
{
	char s[50+1];
	scanf("%s", s);

	for (i = 0; (s[i]) ; i++)
	{
		if ((s[i] >= 'A') && (s[i] <= 'z')) s[i]+=32;
		printf("%s", s);
	}	
}