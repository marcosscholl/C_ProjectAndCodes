//Verificar se um numero n é primo

#include <stdio.h>
#include <stdlib.h>
int main()
{
	int n = 8;
	int d;

	for (d = 2; (n%d); d+= (d == 2)?1:2);
	printf("%d %se primo\n", n, (n == 2)?"":"nao ");
	return(0);

}

//Decompor um numero n em fatores primos

//8 = 2 2 2
//30 = 2 3 5
