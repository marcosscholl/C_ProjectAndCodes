//Calcular a parte inteira da raiz quadrada de um numero n

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main()
{	


	int n = 21;
	int d = 1;

	while((d*d) <= n) d++;
	printf("%d\n", d-1);
	return(0);

}