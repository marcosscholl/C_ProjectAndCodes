//Digitar um string e dizer quais vogais nao aparecem nessa string

#include <stdio.h>
#include <stdlib.h>
int main()
{
	//String msg = "Gremio";
	char msg[50+1]; 

	char chars[5] ;
	chars[0] = 'a';
	chars[1] = 'e';
	chars[2] = 'i';
	chars[3] = 'o';
	chars[4] = 'u';

	scanf("%s", msg);

	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; i < msg[j]; j++)
		
			if (msg[j] == chars[i]) break;
			if (msg[j] != chars[i]) printf("%c",chars[i] );
				
		
	}
	return 0;
}

/*
65
69
73
79
85

97
101
105
111
117
*/