//Calcular o mdc de  2 numeros comum

#include <stdio.h>
#include <stdlib.h>

int main()
{
	int n1 = 179, n2 = 69;
	int t;
	if ( n1 < n2)
	{
		t = n1;
		n1 = n2;
		n2 = t;
	}

	while (t = (n1%n2))
	{
		n1 = n2;
		n2 = t;
	}
	printf("%d\n",n2);
	return(0);

}

/*
36 16 | '2' 0
180 122 | 58 6 4 '2' 0
179 69 | 41 28 13 2 '1' 0

*/