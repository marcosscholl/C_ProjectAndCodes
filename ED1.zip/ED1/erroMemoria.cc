//erroMemoria
#include <stdio.h>
#include <stdlib.h>

int main()
{
	char w[5], i = 0;
	w[5] = 5;
	printf("%d\n", i);
	return 0;
}
