//Decompor

#include <stdio.h>
#include <stdlib.h>
int main()
{
	int n = 8;
	int d;

	for ( d = 2; (n > 1); )
	{
		if (n%d) d += (d == 2)?1:2;
		else
		{
			printf("%d ", d);
			n /= d;
		}
	}
	return(0);

}