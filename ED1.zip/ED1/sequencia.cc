//mostrar os n primeiros números da  sequencia de fibonnaci

#include <stdio.h>
#include <stdlib.h>

int main()
{	int n1 = 1, n2 = 1, n = 6;
	while(n--)
	{
		printf("%d ", n2);
		n1 += n2;
		n2 = n1-n2;
	}
	return(0);

}