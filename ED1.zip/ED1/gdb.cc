//gdb
#include <stdio.h>
#include <stdlib.h>

int main ()
{	int n1, n2, m1, m2;
	printf("Digite o n1: "); scanf("%d", &n1);
	printf("Digite o n2: "); scanf("%d", &n2);
	m1 = n1;
	m2 = n2;

	while(m1 != m2)
		if (m1 < m2) m1 += n1;
		else m2 += n2;
	printf("mmc: %d\n", m1);
	return(0);
}

/*
r = run
c = continueb = breakpoint


*/