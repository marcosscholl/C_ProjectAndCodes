//gcc -pthread pi_paralelo.c -o pi_paralelo && time ./pi_paralelo
//https://computing.llnl.gov/tutorials/pthreads/

#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <pthread.h>

#define MAX 1000000.0
#define THS 4

float res[THS];

struct timeval difftimeval(struct timeval b, struct timeval e)
{   struct timeval r;

    if (b.tv_sec == e.tv_sec)
    {   r.tv_sec = 0;
        r.tv_usec = e.tv_usec-b.tv_usec;
    }
    else
    {   r.tv_sec = e.tv_sec-b.tv_sec-1;
        r.tv_usec = (1000000-b.tv_usec)+e.tv_usec;
        if (r.tv_usec >= 1000000)
        {   r.tv_sec++;
            r.tv_usec -= 1000000;
        }
    }
    return(r);
}

void *work(void *t)
{	int tid = (int)t;
	int ind = tid; //qual
	int qtd = THS; //de quantos
	int inf = (int)(MAX*ind/qtd);
	int sup = (int)(MAX*(ind+1.0)/qtd-1);
	int n;

	printf("thread: %d started\n",tid);
	res[tid] = 0.0;
	for (n = inf; (n <= sup); n++) res[tid] += ((n%2)?-1.0:1.0)/(2.0*n+1.0);
	printf("thread: %d done, result: %0.15f\n",tid,res[tid]);
	pthread_exit(NULL);
}

int main()
{	struct timeval ini;
	gettimeofday(&ini,NULL);

	pthread_t thread[THS];
	pthread_attr_t attr;
	int t;
	float pi;

	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_JOINABLE);
	for (t = 0; (t < THS); t++)
	{	printf("main: creating thread %d\n",t);
		if (pthread_create(&thread[t],&attr,work,(void *)t)) exit(-1);
	}
	pthread_attr_destroy(&attr);
	pi = 0.0;
	for (t = 0; (t < THS); t++)
	{	if (pthread_join(thread[t],NULL)) exit(-1);
		printf("main: completed join with thread %d\n",t);
		pi += res[t];
	}
	printf("main: pi = %0.15f\n",4.0*pi);

	struct timeval fim;
	gettimeofday(&fim,NULL);
	struct timeval dif = difftimeval(ini,fim);
	printf("main: time = %u.%06us",dif.tv_sec,dif.tv_usec);

	pthread_exit(NULL);
	return(0);
}

