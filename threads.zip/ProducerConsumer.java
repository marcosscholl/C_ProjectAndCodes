import java.util.*;

public class ProducerConsumer
{	public static void main(String args[])
	{	Buffer buffer = new Buffer();
		Thread producer = new Producer(20,buffer);
		Thread consumer = new Consumer(20,buffer);
		System.out.println("Started");
		producer.start();
		consumer.start();
		try
		{	producer.join();
			consumer.join();
		}
		catch (Exception e) {}
		System.out.println("Done");
	}
} 

class Buffer
{	private Vector contents = new Vector();
  	private int size = 5;
	
	public synchronized void put(int v)
	{	while (contents.size() == size)
		{	System.out.println("Buffer full");	
			try
			{	wait();
			}
			catch (Exception e) {}
		}
		contents.add(v);
		notifyAll();
	} 

	public synchronized int get()
	{	while (contents.isEmpty())
		{	System.out.println("Buffer empty");
			try
			{	wait();
			}
			catch (Exception e) {}
		}
		notifyAll();
		return((Integer)contents.remove(0));
	}

}

class Producer extends Thread
{	private int n;
	private Buffer buffer;
  	
	public Producer(int q, Buffer b)
	{	super();
		n = q;
		buffer = b;
	}
    
	public void run()
	{	for (int i = 0; (i < n); i++)
		{	try
			{	buffer.put(i);
			}
			catch (Exception e) {}
			System.out.println("Produced "+i);
		}
	}
}

class Consumer extends Thread
{	private int n;
	private Buffer buffer;
  	
	public Consumer(int q, Buffer b)
	{	super();
		n = q;
		buffer = b;
	}
    
	public void run()
	{	for (int i = 0; (i < n); i++)
		{	try
			{	System.out.println("Consumed "+buffer.get());
			}
			catch (Exception e) {}
		}
	}
}

