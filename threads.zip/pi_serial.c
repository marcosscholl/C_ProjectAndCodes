//gcc pi_serial.c -o pi_serial && time ./pi_serial

#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

#define MAX 1000000.0

struct timeval difftimeval(struct timeval b, struct timeval e)
{   struct timeval r;

    if (b.tv_sec == e.tv_sec)
    {   r.tv_sec = 0;
        r.tv_usec = e.tv_usec-b.tv_usec;
    }
    else
    {   r.tv_sec = e.tv_sec-b.tv_sec-1;
        r.tv_usec = (1000000-b.tv_usec)+e.tv_usec;
        if (r.tv_usec >= 1000000)
        {   r.tv_sec++;
            r.tv_usec -= 1000000;
        }
    }
    return(r);
}

int main()
{	struct timeval ini;
	gettimeofday(&ini,NULL);

	int ind = 0; //qual
	int qtd = 1; //de quantos
	int inf = (int)(MAX*ind/qtd);
	int sup = (int)(MAX*(ind+1.0)/qtd-1);
	float res = 0.0;
	int n;

	for (n = inf; (n <= sup); n++) res += ((n%2)?-1.0:1.0)/(2.0*n+1.0);
	printf("res = %0.15f\n",res);
	printf("pi = %0.15f\n",4.0*res);

	struct timeval fim;
	gettimeofday(&fim,NULL);
	struct timeval dif = difftimeval(ini,fim);
	printf("time = %u.%06us",dif.tv_sec,dif.tv_usec);

	return(0);
}

