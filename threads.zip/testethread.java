class mthread extends Thread
{   int contador,tempo;

    public mthread(int c, int t, String n)
    {   super(n);
        contador = c;
        tempo = t;
        start();
    }
    public void run()
    {   while (contador > 0)
        {   System.out.println(getName()+":"+contador);
            contador--;
            try
            {   sleep(tempo);
            }
            catch (InterruptedException ie)
            {   System.out.println("ERRO: thread sleep");
            }
        }
    }
}

class testethread
{   public static void main(String args[])
    {   int contador = 50;
        mthread t1 = new mthread(20,1000,"t1");
        mthread t2 = new mthread(20,200,"t2");
        while (contador > 0)
        {   System.out.println("main:"+contador+" "+
                               t1.toString()+"="+t1.isAlive()+" "+
                               t2.toString()+"="+t2.isAlive());
            contador--;
            try
            {   Thread.sleep(500);
            }
            catch (InterruptedException ie)
            {   System.out.println("ERRO: main sleep");
            }
        }
    }
}
