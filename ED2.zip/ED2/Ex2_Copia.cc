void remove(struct lde *&l)
{	struct lde *p, *t, *ant;
	int r;
	for (p = l; p != NULL && p->proximo != NULL;)
	{	printf("11\n");
		printf("p -> informacao = %d\n", p -> informacao );
		printf("p->proximo->informacao = %d\n", p->proximo->informacao);

		if (p -> informacao == p->proximo->informacao)
		{	
			printf("22\n");
			r = p->informacao;
			
			printf("ANTERIOR = %d\n", ant->informacao);
			printf("REFERENCIA = %d\n", r);

			while(p->informacao == r)
			{	printf("Repetido: %d\n", p->informacao);			
				t = p;
				if (p->proximo != NULL)
				{	
					p = p->proximo;
					delete(t);

				} 
				else 
				{	printf("SAIU NO %d\n", p->informacao );
					break;
				}
				


			}	
			ant->proximo = p;

			printf("sai do Laço.\n");
			printf("SAIU NO %d\n", p->informacao );
			if (p-> anterior == NULL) 
			{	printf("33\n");
				l = p->proximo;
			}
			/*
			else  if ( p->informacao != r)
			{	printf("44\n");
				//p->anterior -> proximo = p->proximo;
				ant->proximo = p->proximo;
			}
			*/

			/*
			if (p->proximo != NULL) 
			{	printf("55\n");
				p->proximo-> anterior = p-> anterior;
			}
			*/
/*
4 2 4 2 4 2 4 2 4 1 4 3 4 2 4 2 5 3 5 3 5 3 5 3 5 10 5 11 4 1
/*
			/*
			printf("66\n");
			t = p;
			p = p->proximo;


			delete(t);
			*/
			printf("77\n");
		}
		else {	ant = p;
			p = p-> proximo;	
		}
		printf("88\n");
		// 4 2 4 2 4 2 4 2 4 1 4 3 4 2 4 2 5 3

	}

}