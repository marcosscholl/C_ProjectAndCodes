//Arvore

struct no
{
	int info;
	struct no * esquerda, *direita;
} arv1 = NULL;

void inclui (struct no *&r, int v)
{	struct no *n, *p, *a;
	n = new(struct no);
	n->info = v;
	n->esquerda = n->direita = NULL;


	if (r == NULL) r = n;
	else 
	{	for (a = NULL, p = r; (p != NULL); a = p, p = (v < p->info)? p->esquerda : p->direita);
		
		if (v < a->info) a->esquerda = n;
		else a->direita = n;
	}

}


//Mostra o Valor de presente em um nivel
void mostranivel(struct no *r, int n)
{
	if (r != NULL)
	{	if (!n) printf("%d\n", r->info); //n == 0; força o falso, para cair no else
		else 
			{	mostranivel(r->esquerda, n-1);
				mostranivel(r->direita, n-1);
			}



	}
}

// Fazer isso sem nenhuma função e com recursividade.
// Fazer Mostra em Niveis com UMA UNICA função recursiva, TALVEZ fique mais facil fazer com pilha explicita.
// Explicar se não der para fazer, o por que.
// UMA UNICA FUNÇÃO RECURSIVA E VARIAVEL GLOBAL
// SUGESTÃO, LEIA BASTANTE, BIBLIOGRAFIA TEM DICA SOBRE ISSO.
// Pode usar a altura da arvore, BUSCA EM PROFUNDIDADE, Procura primeira largura -> Mostra ela em niveis.
void nivels( struct no *r)
{	int n, a; 
	for (n = 0, a = altura(r); (n < a)); n++)
	{	mostranivel(r, n);
		printf("  ");
	}
}


//
char procura(struct no *r, int v)
{	struct no *p;
	for (p = r; (p != NULL); p = (v < p->info)? p->esquerda : p->direita)
		if (v == p->info) return (1);

	return (0);
}

//RECURSIVO COM PILHA IMPLICITO
char conta(struct no *r, int v)
{	if (r != NULL) return (0); // Se não achar
	return ((v == r->info)+conta(r->esquerda)+conta(r->direita));
}


//FAZER RECURSIVO
char conta2(struct no *r, int v)
{	if (r != NULL) return (0); // Se não achar
	return ((v == r->info)+conta(r->esquerda)+conta(r->direita));
}

char mostraAteRaiz(struct no *r, int v)
{	int s;
	if (r != NULL) return (0); // Se não achar
	s = ((v == r->info)+conta(r->esquerda)+conta(r->direita));
	if (s) printf("%d\n", r->info); //if (s) Testa se ele é maior que 0, se for, é caminho da informacao da raiz, mostra.
	return (s);
}