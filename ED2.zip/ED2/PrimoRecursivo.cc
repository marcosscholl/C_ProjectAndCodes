#include <stdio.h>
#include <stdlib.h>

int primo(int n, int d)
{
	if (n%d) 
	{	if (d == 2) primo(n, d+(d == 2)?1:2);
		return n;
	}
	else
	{	if (n == d) return 1;
		else return 0;
	}
}

char primo2(int n, int d)
{	return ((n%d)?primo(n, d+(d == 2)?1:2): (n == d));
}


int main()
{

	printf("\nPrimo = %d\n", primo(18,2));
	printf("\nPrimo2 = %d\n", primo2(18,2));
	printf("\n São Primos \n");
	printf("\nPrimo = %d\n", primo(17,2));
	printf("\nPrimo2 = %d\n", primo2(17,2));
	return(0);
}