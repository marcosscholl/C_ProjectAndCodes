#include <stdio.h>
#include <stdlib.h>

#define MAX 10

/**************************************************
LISTAS DUPLAMENTE ENCADEADAS

  0   1   2   3   4
+---+---+---+---+---+
| C | A | C | B | E | INFORMAÇÃO
+---+---+---+---+---+
| 3 | -1| 2 | 1 | 0 | ANTERIOR
+---+---+---+---+---+
| -1| 3 | 3 | 0 |-1 | PROXIMO
+---+---+---+---+---+
| V | V | F | V | F | ALOCADO
+---+---+---+---+---+
Inicio = 1

-- A <-> B <-> C --
**************************************************/


struct lde
{	int informacao;
	struct lde *proximo;
	struct lde *anterior;
} *lista = NULL;

void inicializa(struct lde *&l)
{	struct lde *t;

	while (l != NULL) 
	{	t = l;
		l = l -> proximo;
		delete(t);
	}

}



void mostra(struct lde *l)
{	struct lde *i;

	// printf("inicio = %d\n",l);
	for (i = l; (i != NULL); i = i->proximo) printf("%d ",i->informacao);
		printf("\n");

}

/*
char encontra(struct lde l, int v)
{	int i;

	for (i = l.inicio; (i != -1); i = l.dado[i].proximo)
		if (l.dado[i].informacao == v) return(1);
	return(0);
}
*/

 struct lde *procura(struct lde *l, int v)
{	struct lde *i;

	for (i = l; (i != NULL); i = i->proximo)
		if (i -> informacao == v) return(i);
	return(0);
}

void incluiinicio(struct lde *&l, int v)
{	struct lde *n;
	n = new (struct lde);

	n -> informacao = v;
	n-> anterior = NULL; // Mudar isso?
	n -> proximo = l;
	if (l != NULL) l -> anterior = n;
	l = n;
	
}

void incluifim(struct lde *&l, int v)
{	struct lde *n, *p;
	n = new (struct lde);
	n-> informacao = v;
	n-> proximo = NULL;
	if (l == NULL) //Se for o primeiro a ser inserido
	{	n-> anterior = NULL;
		l = n;
	}
	else
	{	for (p = l; (p->proximo != NULL); p = p->proximo);
		p-> proximo = n;
		n-> anterior = p;
	}
	
}

void incluidepoisde(struct lde *&l, int r, int v)
{	struct lde *n, *p;
	n = new (struct lde);

	if ((p = procura(l,r)) != NULL)
	{	n->informacao = v;
		n->anterior = p;
		n->proximo = p->proximo;
		p->proximo = n;
		if (n->proximo != NULL) /*l.dado[l.dado[n].proximo].anterior = n;*/ n->proximo ->anterior = n; //Verificar Isso: 
		
	}
}

void incluiantesde(struct lde *&l, int r, int v)
{	struct lde *p, *n;

	if ((p = procura(l,r)) != NULL)
	{	
		n->informacao = v;
		n->anterior = p->anterior;
		n->proximo = p;
		p ->anterior = n;
		if (n->anterior == NULL) l = n;
		else n->anterior -> proximo = n;
	}
}

void incluiemordem(struct lde &, int v)
{
}

void exclui(struct lde *&l, int r)
{	struct lde *p;
	if ((p = procura(l,r)) != NULL)
	{	if (p-> anterior == NULL) l = p->proximo;
		else p->anterior -> proximo = p->proximo;
		if (p->proximo != NULL) p->proximo-> anterior = p-> anterior;
		delete(l,p);
	}
}

void excluiTodos(struct lde *&l, int r)
{	struct lde *p, *t;
	for (p = l; p != NULL; /*p = p -> proximo*/)
	{
		if (p -> informacao == r)
		{	if (p-> anterior == NULL) l = p->proximo;
			else p->anterior -> proximo = p->proximo;
			if (p->proximo != NULL) p->proximo-> anterior = p-> anterior;
			
			t = p;
			p = p->proximo;

			delete(t);
		}
		else p = p-> proximo;	
	}

}

void remove(struct lde *&l)
{	struct lde *p, *t, *ant;
	ant = NULL;
	int r;
	int i;
	//Eu não queria fazer isso, mas não teve jeito. 
	for (i = 0; i < 5; i++)
	{
		for (p = l; p != NULL && p->proximo != NULL;)
		{	if (p -> informacao == p->proximo->informacao)
			{	r = p->informacao;
				while(p->informacao == r)
				{	t = p;
					if (p->proximo != NULL)
					{	p = p->proximo;
						delete(t);
					} 
					else 
					{	p = p->proximo;
						break;
					}		
				}	
				
				//Pra Funcionar De Boa. 	
				if (p == NULL && ant == NULL)	l = p;
				else if (p == NULL && ant != NULL)
				{	l = ant;
					ant->proximo = p;
				}
				else if (ant == NULL && p != NULL)	l = p;
				else
				{	if (p-> anterior == NULL) l = p->proximo;
					ant->proximo = p;
					if (p-> anterior == NULL) l = p->proximo;
				}			
			}
			else 
			{	ant = p;
				p = p-> proximo;	
			}
		}
	}
}

int main()
{	int o, v, r;

	inicializa(lista);
	do
	{	printf("1)inicializa 2)mostra 3)procura 4)incluiinicio 5)incluifim 6)incluidepoisde 7)incluiantesde 8)exclui 9)ExcluiTodos  10) RemoveBloco 0)sai: ");
		scanf("%d",&o);
		switch (o)
		{	case 1: inicializa(lista);
					break;
			case 2: mostra(lista);
					break;
			case 3: printf("valor: "); scanf("%d",&v);
					//printf("%s encontrado\n",(procura(lista,v) != -1)?"":"nao ");
					break;
			case 4: printf("valor: "); scanf("%d",&v);
					incluiinicio(lista,v);
					break;
			case 5: printf("valor: "); scanf("%d",&v);
					incluifim(lista,v);
					break;
			case 6: printf("referencia: "); scanf("%d",&r);
					printf("valor: "); scanf("%d",&v);
					incluidepoisde(lista,r,v);
					break;
			case 7: printf("referencia: "); scanf("%d",&r);
					printf("valor: "); scanf("%d",&v);
					incluiantesde(lista,r,v);
					break;
			case 8: printf("referencia: "); scanf("%d",&r);
					exclui(lista,r);
					break;
			case 9: printf("referencia: "); scanf("%d",&r);
					excluiTodos(lista,r);
					break;
			case 10:
					remove(lista);
					break;
		}
	}
	while (o);
	inicializa(lista);

	return(0);
}

