//RECURSIVIDADE

int fat(n)
{	return((n < 2)?1:n*fat(n-1));
}

fat(3) = 3*fat(2) = 3*2 = 6
fat(2) = 3*fat(1) = 2*1 = 2
fat(1) = 1



int tamanhoString(char *s)
{	//(*s = o que tem na posicao s (minhaString))
	return ((*s) ? 1+tamanhoString(s+1) : 0);
	//se string S diferente de 0, retorna taamnho da string +1
	// se não retorna 0
}

{'a', 'b', 'c', 0}
tamanhoString("abc") = 1+tamanhoString("bc") = 1+2 = 3;
tamanhoString("ab") = 1+tamanhoString("c") = 1+1 = 2;
tamanhoString("a") = 1+tamanhoString("") = 1+0 = 1;
tamanhoString("") = 0;


//ALGORITMO DO PINTOR
Não recursivo

struct no
{	int x, y;
	int prox;
}

//PILHA EXPLICITA
inicializa pilha
push (x,y) /acrescenta a cordenada, onde o cara clicou, apartir daqui preenche
enquanto a pilha nao esta vazia faca
	pop(x, y) //desempilha
	se ((x,y) dentro da imagem)
		se (pixel em (x,y) igual a cor de fundo)
			pinta pixel em (x,y) com nova cor
			push(x+1,y)
			push(x+1,y)
			push(x,y+1)
			push(x, y+2)
		fimse
	fimse
fimenquanto


1) Quando chama o metodo recursivo, ele volta a executar a primeira linha do método.
2) Na pilha vão os parametros, as variaveis locais e a linha onde esta a execução. Linha que chamou recursão.
3) Quando fim é executado, Desempilha

*** a pilha SEMPRE acaba vazia!!!!

//Tamanho da String
Recursão com variavel Global

int c = 0;
char *s;
void tamanho(int p)
{	if (s[p] != '\0')
	{	c++;
		tamanho(s, p+1);
	}
}

Recursão Sem variavel Global
int tamanho (int p)
{	return ((s[p] != '\0') ? 0:1+tamanho(s, p+1));
}


expressao = numero | expressao operador expressao
1+2+3+2


Perguntar Largura e Altura,
Quantos % de Bomba
Pintor com Pilha Implicita e Explicita
