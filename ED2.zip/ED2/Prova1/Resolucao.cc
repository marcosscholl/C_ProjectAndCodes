1)
int t;

struct lde *p;

for (t = 0, p = l; (p != NULL); t++, p = p->prox);
	//descobre o tamanho da lista

for (a = rand()%t, p = l; (p != NULL); t++, p = p->prox);
for (t = 0, p = l; (p != NULL); t++, p = p->prox);




2)
//Remover Blocos
for (ib = fb = p = l; (p != NULL); p = p-prox)
{	if (p->info == ib->info) fb = p;
	else 
	{	if (ib != fb) // exclui o bloco de ib a fb
		ib = fb = p = l;
	}
}



3) // Soma 123 + 89
1 2 3
  8 9
r = inicializa();
int vaium = 0;
for (p1 = n1; (p1->prox != NULL); p1 = p1-prox);
for (p2 = n2; (p2->prox != NULL); p2 = p2-prox);
while((p1 != NULL) || (p2 != NULL))
{	incluifim(r, (p1->info + p2->info + vaium)%10);
	vaium = (p1->info + p2->info + vaium) > 10);
	if (p1 != NULL) p1 = p1->ant;
	if (p2 != NULL) p2 = p2->ant;

}
if (vaium > 0) incluiinicio(r, vaium);






