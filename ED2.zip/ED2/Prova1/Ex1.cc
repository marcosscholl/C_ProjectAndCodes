void embaralha(struct lde *&l)
{	struct lde *p, *a, *a2, *pAnt, *pProx;
	srand(time(NULL));

	int r, i, t = 0;
	a = l;
	while (t <= 5)
	{	t++;
		r = (rand() % 19 + 1 );
		
		for (i = 0, p = l;  p != NULL ; i++, p = p->proximo)
		{	if (i == r)
			{	pAnt = p->anterior;
				if (p->proximo != NULL) pProx = p->proximo;
				else pProx = NULL; //Não resolve, Quebra quando tenta acessar o Proximo do Ultimo. Sempre no NULL

				pAnt->proximo = pProx;
				pProx->anterior = pAnt;


				p -> anterior = NULL;
				p->proximo = a;

				if (a != NULL)	a -> anterior = p;
				a = p;
				l = a;
				
			}
		}
	}
	
}