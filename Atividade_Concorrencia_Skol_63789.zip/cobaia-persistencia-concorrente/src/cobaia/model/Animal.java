package cobaia.model;

import java.io.Serializable;
import java.util.Date;

public class Animal implements Serializable, IModel {

    private Integer id;
    private String  nome;
    private String  tipo;
    private String  raca;
    private Date    dataNascimento;
    private String  dono;
    private Integer versao = 0;

    public Integer getVersao() {
		return versao;
	}

	public void setVersao(Integer versao) {
		this.versao = versao;
	}

	public Date getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(Date dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getDono() {
        return dono;
    }

    public void setDono(String dono) {
        this.dono = dono;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Animal other = (Animal) obj;
        if (this.id != other.id && (this.id == null || !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 17 * hash + (this.id != null ? this.id.hashCode() : 0);
        return hash;
    }

   

    @Override
	public String toString() {
		return "Animal [id=" + id + ", nome=" + nome + ", tipo=" + tipo
				+ ", raca=" + raca + ", dataNascimento=" + dataNascimento
				+ ", dono=" + dono + ", versao=" + versao + "]";
	}

	@Override
    public boolean isPersistent() {
        return id != null;
    }

}
