package cobaia.model;

public interface IModel {

    boolean isPersistent();
}
