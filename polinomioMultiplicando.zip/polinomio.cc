#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 100

struct Termo{
    float coef;
    float expo;
    struct Termo * prox;
};

typedef struct Termo* Poli;


/*
void inicializa(struct Pol *&l)
{	struct Pol *t;

	while(l != NULL)
	{
		t = l;
		l = l->prox;
		delete(t);
	}
}
*/



void mostra(Poli p){
  struct Termo *t;
   
  t = p->prox;
  while(t != p){
    printf("%0.2f*x^%0.2f",t->coef,t->expo);
    t = t->prox;
    if(t != p)
    { if(t->coef >= 0.0) printf(" + ");
      else printf(" ");
    }
  }
  printf("\n");
}


Poli InicializaPolinomio(){
  struct Termo *p;
  p = new (struct Termo);
  p->coef = 0.0;
  p->expo = -1;
  p->prox = p;
  return p;
}


void InsereTermo(Poli p, float coef, float expo)
{
	
struct Termo *t, *at,*q;
 
/*
2*x^2+5*x^3+1*x^0
2*x^2+5*x^3+1*x^0
*/

  q = new (struct Termo);

  q->coef = coef;
  q->expo = expo;
  /* Busca a posição correta para inserir o novo termo,
     O novo termo será inserido entre os termos apontados 
     por at e t.
  */
  at = p;
  t = p->prox;
  while(expo < t->expo){
    at = t;
    t = t->prox;
  }
  q->prox = t;
  at->prox = q;

}

Poli geraPolinomio(char str[])
{	
	int i = 0, n, tam;
	
	char c;
	float coef = 0.0, expo = 0.0, sinal = 1.0;
	Poli p;
	p = InicializaPolinomio();

	while (str[i] != '\0')
	{
		sscanf(str+i, " %f * x ^ %f %n",&coef, &expo, &n);
		i += n;
		InsereTermo(p, sinal*coef, sinal*expo);

		sscanf(str+i,"%c %n",&c,&n);
		
		if (c == '-')
		{	sinal = -1.0;
			i += n;
		} 

		//printf("coef = %f\n", coef);
		//printf("Expo %f\n", expo);

	}
	return p;
}


Poli soma(Poli p1, Poli p2)
{
	struct Termo *p1_a, *p2_a, *novo;
	float aux;
	Poli novo_;
	novo_ = InicializaPolinomio();
	novo = novo_;

	p1_a = p1->prox;
	p2_a = p2->prox;

	printf("TETAAAA\n");
	while (p1_a->expo != -1 || p2_a->expo != -1)
	{	if (p1_a->expo > p2_a->expo)
		{	InsereTermo(novo, p1_a->coef, p1_a->expo);
			novo = novo->prox;
			p1_a =  p1_a->prox;
		}
		else if (p1_a->expo < p2_a->expo)
		{	InsereTermo(novo, p2_a->coef, p2_a->expo);
			novo = novo->prox;
			p2_a = p2_a->prox;
		}
		else
		{ /* p1_a->expo == p2_a->expo */
	      	aux = p1_a->coef + p2_a->coef;
	        InsereTermo(novo, aux, p2_a->expo);
	        novo = novo->prox;
	      	p1_a = p1_a->prox;
	      	p2_a = p2_a->prox;
	    }
	}
	return novo_;

}
/*
2*x^2+5*x^3+1*x^0
2*x^2+5*x^3+1*x^0
*/
Poli subtracao(Poli p1, Poli p2)
{	struct Termo *p1_a, *p2_a, *novo;
	float aux;
	Poli novo_;
	novo_ = InicializaPolinomio();
	novo = novo_;

	p1_a = p1->prox;
	p2_a = p2->prox;

	while (p1_a->expo != -1 || p2_a->expo != -1)
	{
		if(p1_a->expo > p2_a->expo)
		{	InsereTermo(novo, p1_a->coef, p1_a->expo);
			p1_a = p1_a->prox;
			novo = novo->prox;
		}
		else if (p1_a->expo < p2_a->expo)
		{	InsereTermo(novo, p2_a->coef, p2_a->expo);
			novo = novo->prox;
			p2_a = p2_a->prox;
		}
		else 
		{	if(p1_a->coef > p2_a->coef) aux = p1_a->coef - p2_a->coef;
			else aux = p2_a->coef - p1_a->coef;
			InsereTermo(novo, aux, p1_a->expo);
			p1_a = p1_a->prox;
			p2_a = p2_a->prox;
			novo = novo->prox;
		}
	}
	return (novo_);
/*
1 10*x^2+10*x^3 5*x^2+5*x^3 -
*/
}


Poli multiplicacao(Poli p1, Poli p2)
{	struct Termo *p1_a, *p2_a, *novo;
	float aux;
	Poli novo_;
	novo_ = InicializaPolinomio();
	novo = novo_;

	p1_a = p1->prox;
	p2_a = p2->prox;

	for(; p1_a->expo != -1; p1_a = p1_a->prox)
	{
		for(; p2_a->expo != -1; p2_a = p2_a->prox)
		{
			InsereTermo(novo, p1_a->coef*p2_a->coef, p1_a->expo + p2_a->expo);
		}
		p2_a = p2->prox;
	}
	return(novo_);
}

int main (){
    int o;
    char str1[MAX];
    char str2[MAX];
    char op;
    Poli p1, p2, result;
    p1 = InicializaPolinomio();
    p2 = InicializaPolinomio();
    result = InicializaPolinomio();


     do
    {   printf("1)InsereExpressão    2)Calcula   3)Mostra 5) inicializa  0) sair: ");
        scanf("%d",&o);
        switch (o)
        {   case 1: 
            printf("Insere Expressão\n");
            printf("Primeiro Polinomio\n");
            scanf("%s",str1 );
            p1 = geraPolinomio(str1);

            printf("Segundo Polinomio\n");
            scanf("%s",str2 );
            p2 = geraPolinomio(str2);


            printf("Operação\n");
			scanf("\n%c", &op );
			printf("%c\n", op );

			printf("MOSTRA OS POLINOMIOS\n");
			mostra(p1);
			mostra(p2);
			printf("\n");
			//result = soma(p1, p2);
			//result = subtracao(p1, p2);
			result = multiplicacao(p1, p2);
			printf("Resultado:\n");
			mostra(result);
			



			
			
			
                    break;

            case 2: //calcula(expressao);
                    break;
            case 3: 
            mostra(result);
            //mostra(pol2);
            		break;
        }

    }	
    while (o);
    return 0;
}

