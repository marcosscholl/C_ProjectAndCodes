#include <stdio.h>
#include <stdlib.h>

#define MODO 2

const int CONTROLE = MODO *2;
const int metade = CONTROLE/2;

struct nob
{   char qtd;
    int codigos[CONTROLE];
    int posicoes[CONTROLE];
    int filhos[CONTROLE+1];
} no;

void inicializaNo()
{   no.qtd=0;
    for (int i=0; i < CONTROLE+1; i++)
    {   no.filhos[i]=-1;
        if (i<CONTROLE)
        {   no.codigos[i]=0;
            no.posicoes[i]=-1;
        }
    }
}

int procura(int codigo, int pos)
{   FILE *indice = fopen("indice.ind", "r");
    fseek(indice, pos, SEEK_SET);
    fread(&no, sizeof(struct nob), 1, indice);
    int i;
    for (i=0; i<no.qtd; i++)
    {   if (no.codigos[i] >= codigo) break;
    }
    if (i != no.qtd && no.codigos[i] == codigo) return no.posicoes[i];
    if (no.filhos[i] < 0) return -1;
    return procura(codigo, no.filhos[i]);
}

int main()
{   
    FILE *arquivo, *indice;
    if ((arquivo = fopen("arq.csv", "r+")) == NULL)
    {   printf("o arquivo especificado não existe\n");
        return 0;
    } else if ((indice = fopen("indice.ind", "r+")) == NULL)
    {   printf("o arquivo indice não existe\n");
        return 0;
    }

    int endereco;
    //Posiciona no Inicio
    fseek(indice, 0, SEEK_SET);
    //Le a Raiz
    fread(&endereco, sizeof(int), 1, indice);
    fclose(indice);
    
    int codigo;
    printf("\nBuscar Codigo: ");
    scanf("%d", &codigo);
    
    inicializaNo();
    char linha[1001];
    
    int posicao = procura(codigo, endereco);
    if (posicao < 0) printf("Codigo não foi encontrado\n");
    else
    {   //Posiciona
    	fseek(arquivo, posicao, SEEK_SET);
    	//Le a linha 
    	fgets(linha, 1000, arquivo);
        printf("%s", linha);
    }
    fclose(arquivo);
}