#include <stdio.h>
#include <stdlib.h>

#define MODO 2
const int CONTROLE = MODO *2;

struct nob
{   char qtd;
    int codigos[CONTROLE];
    int posicoes[CONTROLE];
    int filhos[CONTROLE+1];
} no;

void inicializaNo()
{   no.qtd=0;
    for (int i=0; i<CONTROLE+1; i++)
    {   no.filhos[i]=-1;
        if (i<CONTROLE)
        {   no.codigos[i]=0;
            no.posicoes[i]=-1;
        }
    }
}

void apagar(int codigo, int posicao)
{   if (posicao < 0) return;
    FILE *indice = fopen("indice.ind", "r+");
    fseek(indice, posicao, SEEK_SET);
    fread(&no, sizeof(struct nob), 1, indice);
    int i;
    for (i=0; i<no.qtd; i++)
    {   if (no.codigos[i] >= codigo) break;
    }
    if (no.codigos[i] == codigo)
    {   no.posicoes[i] = -2;
        fseek(indice, posicao, SEEK_SET);
        fwrite(&no, sizeof(struct nob), 1, indice);
    }
    else apagar(codigo, no.filhos[i]);
    fclose(indice);
}

int main()
{   FILE *indice;
    if ((indice = fopen("indice.ind", "r")) == NULL)
    {   printf("o arquivo indice não existe\n");
        return 0;
    }
    int endereco;
    fseek(indice, 0, SEEK_SET);
    fread(&endereco, sizeof(int), 1, indice);
    fclose(indice);
    
    int codigo;
    printf("\nApagar Pessoa\n\n");
    printf("Entre com o Codigo: ");
    scanf("%d", &codigo);
    
    inicializaNo();
    apagar(codigo, endereco);
}
