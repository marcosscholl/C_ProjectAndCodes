#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MODO 2
const int CONTROLE = MODO *2;

struct nob
{   char qtd;
    int codigos[CONTROLE];
    int posicoes[CONTROLE];
    int filhos[CONTROLE+1];
};

void inicializaNo(struct nob no)
{   no.qtd=0;
    for (int i=0; i<CONTROLE+1; i++)
    {   no.filhos[i]=-1;
        if (i<CONTROLE)
        {   no.codigos[i]=0;
            no.posicoes[i]=-1;
        }
    }
}

void vacuum(int posicao, FILE *arquivo)
{   if (posicao == -1) return;
    struct nob no;
    FILE *indice = fopen("indice.ind", "r");
    fseek(indice, posicao, SEEK_SET);
    fread(&no, sizeof(struct nob), 1, indice);
    fclose(indice);
    //FILE *arquivo = fopen(arquivo, "r");
    FILE *novoArqCSC = fopen("arqVacuum.csv", "r+");

    char linha[1000];
    for (int i=0; i<no.qtd; i++)
    {   if (no.posicoes[i] != -2){
            strcat(linha, "");
            fseek(arquivo, no.posicoes[i], SEEK_SET);
            fseek(novoArqCSC, 0, SEEK_END);
            fgets(linha, 1000, arquivo);
            fwrite(linha, sizeof(char), strlen(linha), novoArqCSC);
        }
    }
    
    //fclose(arquivo);
    fclose(novoArqCSC);
    
    for (int i=0; i<=no.qtd; i++)
    {   vacuum(no.filhos[i], arquivo);
    }
}

int main()
{  
     FILE *arquivo, *indice, *novoArqCSC;
    if ((arquivo = fopen("arq.csv", "r+")) == NULL)
    {   printf("o arquivo especificado não existe\n");
        return 0;
    } 
    if ((indice = fopen("indice.ind", "r+")) == NULL)
    {   printf("o arquivo indice não existe\n");
        return 0;
    }

    novoArqCSC = fopen("arqVacuum.csv", "w");
    
    int endereco;
    fseek(indice, 0, SEEK_SET);
    fread(&endereco, sizeof(int), 1, indice);
    
    fclose(novoArqCSC);
    fclose(indice);
    vacuum(endereco, arquivo);
    fclose(arquivo);
}
