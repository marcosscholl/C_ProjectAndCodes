#include <stdio.h>
#include <stdlib.h>

//#define CONTROLE 2
#define MODO 2

const int CONTROLE = MODO *2;

struct nob
{   char qtd;
    int codigos[CONTROLE];
    int posicoes[CONTROLE];
    int filhos[CONTROLE+1];
} no, noMaior, noPai;

struct Pilha
{   int endereco;
    struct Pilha *prox;
} *pilha = NULL;

void push(struct Pilha *&p, int end)
{   struct Pilha *novo = new(struct Pilha);
    novo->prox = p;
    novo->endereco = end;
    p = novo;
}

int pop(struct Pilha *&p)
{   if (p==NULL) return -1;
    int end = p->endereco;
    struct Pilha *i = p;
    p = p->prox;
    delete(i);
    return end;
}

void inicializar(struct Pilha *&p)
{   struct Pilha *t, *i = p;
    while (i != NULL)
    {   t = i;
        i = i->prox;
        delete(t);
    }
    p = NULL;
}

void inicializaNo()
{   no.qtd = 0;
    for (int i = 0; i < CONTROLE+1; i++)
    {   no.filhos[i] = -1;
        if (i < CONTROLE)
        {   no.codigos[i] = 0;
            no.posicoes[i] = -1;
        }
    }
}

void inicializaNoMaior()
{   noMaior.qtd = 0;
    for (int i = 0; i < CONTROLE+1; i++)
    {   noMaior.filhos[i] = -1;
        if (i < CONTROLE)
        {   noMaior.codigos[i] = 0;
            noMaior.posicoes[i] = -1;
        }
    }
}

void inicializaNoPai()
{   noPai.qtd=0;
    for (int i = 0; i < CONTROLE+1; i++)
    {   noPai.filhos[i] = -1;
        if (i < CONTROLE)
        {   noPai.codigos[i] = 0;
            noPai.posicoes[i] = -1;
        }
    }
}


//fseek()       Procura por um byte específico (Começo do arquivo   SEEK_SET    0)
//fread()       le um bloco de dados
//fwrite        escreve um bloco de dados
//fgets()       são funções para ler e escrever strings.
//ftell         retorna a posição corrente de leitura ou escrita no arquivo (em bytes)
void explodir(int codigo, int posicao, int filhoD, int enderecoNo, int enderecoPai)
{   //filhoD, posicao do maior novo nó maior a direira do que explodiu
    FILE *indice = fopen("indice.ind", "r+");
    fseek(indice, enderecoNo, SEEK_SET);
    fread(&no, sizeof(struct nob), 1, indice);
    int codigos[CONTROLE+1];
    int posicoes[CONTROLE+1];
    int filhos[CONTROLE+2];
    printf("METODO EXPLODIR\n");
    //Carrega o nó pro vetor
    for (int i=0; i<CONTROLE; i++)
    {   printf("codigos[%d] = no.codigos[%d] = %d\n", i, i, no.codigos[i]);
        printf("posicoes[%d] = no.posicoes[%d] = %d\n", i, i, no.posicoes[i]);
        printf("filhos[%d] = no.filhos[%d] = %d\n", i, i, no.filhos[i]);

        codigos[i] = no.codigos[i];
        posicoes[i] = no.posicoes[i];
        filhos[i] = no.filhos[i];
    }
    //posiciona o ultimo filho do nó no vetor
    printf("filhos[CONTROLE] = no.filhos[CONTROLE] = %d\n", no.filhos[CONTROLE]);
    filhos[CONTROLE] = no.filhos[CONTROLE];
    
    //Testa se precisa ordenar o nó pra quem subiu
    int i;
    for (i=0; i<CONTROLE+1; i++)
    {   if (i==CONTROLE)
        {   printf("i==CONTROLE\n");
            i++;
            break;
        }
        printf("no.codigos[%d]=%d  >  codigo=%d \n", i, no.codigos[i], codigo);
        if (no.codigos[i] > codigo) break;
    }
    //Temos um vetor de CONTROLE+1 Posicoes ordenados
    if (i==CONTROLE+1)
    {   printf("I == CONTROLE+1\n");
        printf("codigos[CONTROLE] = %d\n",codigo);
        printf("posicoes[CONTROLE] = %d\n",posicao);
        printf("filhos[CONTROLE+1] = %d\n",filhoD);

        codigos[CONTROLE] = codigo;
        posicoes[CONTROLE] = posicao;
        filhos[CONTROLE+1] = filhoD;

    }
    else
    {   printf("ELSE\n");
        for (int j=CONTROLE; j>i; j--)
        {   printf("codigos[%d]=%d  =  codigos[%d]=%d; \n", j, codigos[j], j-1, codigos[j-1]);
            printf("posicoes[%d]=%d  =  posicoes[%d]=%d; \n", j, posicoes[j], j-1, posicoes[j-1]);
            codigos[j] = codigos[j-1];
            posicoes[j] = posicoes[j-1];
        }
        for (int j=CONTROLE; j>i; j--)
        {   printf("filhos[%d]=%d  =  filhos[%d]=%d; \n", j+1, filhos[j+1], j, filhos[j]);
            filhos[j+1] = filhos[j];
        }
        printf("filhos[%d] = %d\n",i+1, filhoD);
        printf("codigos[%d] = %d\n",i, codigo);
        printf("posicoes[CONTROLE+1] = %d\n", i, posicoes);

        filhos[i+1] = filhoD;
        codigos[i] = codigo;
        posicoes[i] = posicao;
    }
    
    //Organiza a Explosão
    inicializaNoMaior();
    printf("inicializaNoMaior()\n");
    printf("noMaior.qtd = 2;\n");
    printf("noMaior.codigos[0] = codigos[3]=%d\n", codigos[3]);
    printf("noMaior.codigos[1] = codigos[CONTROLE]=%d\n", codigos[CONTROLE]);

    printf("noMaior.posicoes[0] = posicoes[3]=%d\n", posicoes[3]);
    printf("noMaior.posicoes[1] = posicoes[CONTROLE]=%d\n", posicoes[CONTROLE]);

    printf("noMaior.filhos[0] = filhos[3]=%d\n", filhos[3]);
    printf("noMaior.filhos[1] = filhos[CONTROLE]=%d\n", filhos[CONTROLE]);
    printf("noMaior.filhos[2] = filhos[CONTROLE+1]=%d\n", filhos[CONTROLE+1]);
    /*
    noMaior.qtd = 2;
    noMaior.codigos[0] = codigos[3];
    noMaior.posicoes[0] = posicoes[3];

    noMaior.codigos[1] = codigos[4];
    noMaior.posicoes[1] = posicoes[4];

    noMaior.filhos[0] = filhos[3];
    noMaior.filhos[1] = filhos[4];
    noMaior.filhos[2] = filhos[4+1];
    */
    int metade = CONTROLE/2;
    noMaior.qtd = metade;
    
    for (int k = 0,c = metade+1; k < metade; k++, c++)
    {
        noMaior.codigos[k] = codigos[c];
        noMaior.posicoes[k] = posicoes[c];
        /*
        0 = 3;
        1 = 4;

        0 = 6;
        1 = 7;
        2 = 8;
        3 = 9;
        4 = 10
        */
        noMaior.filhos[k] = filhos[c];
    }
    noMaior.filhos[metade] = filhos[CONTROLE+1];

    for (int k = 0,c = metade+1; k <= metade; k++, c++)
    {
        //noMaior.filhos[k] = filhos[c];
        /*
        0 = 3
        1 = 4
        2 = 5;

        0 = 6;
        1 = 7;
        2 = 8;
        3 = 9;
        4 = 10;
        5 = 11;
        */
    }


    
     /*
         [1][2][3][4] 5
       [1][2] [3] [4][5] 6
         3     2    3


        [0][1][2][3][4][5][6][7][8][9]
      [0][1][2][3][4] [5] [6][7][8][9][10] 12
             6         2         6
    */

    inicializaNo();
    printf("inicializaNo()\n");

    printf("no.qtd = 2;\n");
    printf("no.codigos[0] = codigos[0]=%d\n", codigos[0]);
    printf("no.codigos[1] = codigos[1]=%d\n", codigos[1]);

    printf("no.posicoes[0] = posicoes[0]=%d\n", posicoes[0]);
    printf("no.posicoes[1] = posicoes[1]=%d\n", posicoes[1]);

    printf("no.filhos[0] = filhos[0]=%d\n", filhos[0]);
    printf("no.filhos[1] = filhos[1]=%d\n", filhos[1]);
    printf("no.filhos[2] = filhos[2]=%d\n", filhos[2]);
    /*
    no.qtd = 2;
    no.codigos[0] = codigos[0];
    no.codigos[1] = codigos[1];
    no.posicoes[0] = posicoes[0];
    no.posicoes[1] = posicoes[1];
    no.filhos[0] = filhos[0];
    no.filhos[1] = filhos[1];
    no.filhos[2] = filhos[2];
    */

    no.qtd = metade;
    
    for (int k = 0; k < metade; k++)
    {
        no.codigos[k] = codigos[k];
        no.posicoes[k] = posicoes[k];
        /*
        0 = 3;
        1 = 4;

        0 = 6;
        1 = 7;
        2 = 8;
        3 = 9;
        4 = 10
        */
        noMaior.filhos[k] = filhos[k];
    }
    noMaior.filhos[metade] = filhos[CONTROLE+1];

    for (int k = 0; k <= metade; k++)
    {
        //no.filhos[k] = filhos[k];
        /*
        0 = 3
        1 = 4
        2 = 5;

        0 = 6;
        1 = 7;
        2 = 8;
        3 = 9;
        4 = 10;
        5 = 11;
        */
    }

    
    //carrega no arquivo 
    fseek(indice, enderecoNo, SEEK_SET);
    fwrite(&no, sizeof(struct nob), 1, indice);
    fseek(indice, 0, SEEK_END);
    int filhoDireitaPai = (int) ftell(indice);
    //novo Pai/Raiz
    printf("filhoDireitaPai = %d\n", filhoDireitaPai);
    fwrite(&noMaior, sizeof(struct nob), 1, indice);
    
    if (enderecoPai == -1)
    {   //Cria novo Nó para Inicio da Arvore, novaRaiz
        inicializaNoPai();
        printf("IF\n");
        printf("inicializaNoPai();\n");

        printf("noPai.qtd = 1;\n");
        printf("noPai.codigos[0]=%d  =  codigos[2] = %d\n",noPai.codigos[0],  codigos[2]);
        printf("noPai.posicoes[0]=%d  =  posicoes[2] = %d\n",noPai.posicoes[0],  posicoes[2]);
        printf("noPai.filhos[0]=%d  =  enderecoNo= %d\n",noPai.filhos[0], enderecoNo);
        printf("noPai.filhos[1]=%d  =  filhoDireitaPai= %d\n",noPai.filhos[1],  filhoDireitaPai);
        noPai.qtd = 1;
        noPai.codigos[0] = codigos[2];
        noPai.posicoes[0] = posicoes[2];
        //filho Menor
        noPai.filhos[0] = enderecoNo;
        // Filho Maior
        noPai.filhos[1] = filhoDireitaPai;
        
        fseek(indice, 0, SEEK_END);
        int novaRaiz = ftell(indice);
        printf("novaRaiz = %d\n", novaRaiz);
        fwrite(&noPai, sizeof(struct nob), 1, indice);
        fseek(indice, 0, SEEK_SET);
        //Atualiza a Raiz no Arquivo
        fwrite(&novaRaiz, sizeof(int), 1, indice);
    }
    else
    {   printf("ELSE\n");
        printf("Endereco Pai = %d\n",enderecoPai);
        fseek(indice, enderecoPai, SEEK_SET);
        //Carrega o Blogo Pai
        fread(&noPai, sizeof(struct nob), 1, indice);
        //Se o pai ja tiver CONTROLE, explode de novo
        if (noPai.qtd == CONTROLE)
        {   printf("\n\nEXPLODIU!\n");
            int pops = 9999;
            printf("explodir(codigos[2], posicoes[2], filhoDireitaPai, enderecoPai, pop(pilha));\n", codigos[2], posicoes[2], filhoDireitaPai, enderecoPai, pops );
            //Explode o Meio do vetor, por ser a nova raiz.
            //[2] = MUDAR PARA CONTROLE/2
            explodir(codigos[2], posicoes[2], filhoDireitaPai, enderecoPai, pop(pilha));
        }
        else
        {   int i;
            for (i=noPai.qtd-1; i>=0; i--)
            {   if (noPai.codigos[i] > codigos[2])
                {   printf("noPai.codigos[%d]=%d > codigos[2]=%d\n", i,noPai.codigos[i], codigos[2]);
                    
                    printf("noPai.codigos[%d]=%d = noPai.codigos[i]=%d\n", i+1,noPai.codigos[i+1], i, noPai.codigos[i]);
                    printf("noPai.posicoes[%d]=%d = noPai.posicoes[i]=%d\n", i+1,noPai.posicoes[i+1], i, noPai.posicoes[i]);
                    printf("noPai.filhos[%d]=%d = noPai.filhos[i]=%d\n", i+2,noPai.filhos[i+2], i, noPai.filhos[i+1]);
                    printf("noPai.filhos[%d]=%d = noPai.filhos[i]=%d\n", i+1,noPai.filhos[i+1], i, noPai.filhos[i]);
                    noPai.codigos[i+1] = noPai.codigos[i];
                    noPai.posicoes[i+1] = noPai.posicoes[i];
                    noPai.filhos[i+2] = noPai.filhos[i+1];
                    noPai.filhos[i+1] = noPai.filhos[i];
                }
                else break;
            }
            if (i==-1)
            {   printf("i==-1\n");

                 printf("noPai.codigos[0]=%d  =  codigos[2] = %d\n",noPai.codigos[0],  codigos[2]);
                printf("noPai.posicoes[0]=%d  =  posicoes[2] = %d\n",noPai.posicoes[0],  posicoes[2]);
                printf("noPai.filhos[0]=%d  =  enderecoNo= %d\n",noPai.filhos[0], enderecoNo);
                printf("noPai.filhos[1]=%d  =  filhoDireitaPai= %d\n",noPai.filhos[1],  filhoDireitaPai);
                noPai.codigos[0] = codigos[2];
                noPai.posicoes[0] = posicoes[2];
                noPai.filhos[0] = enderecoNo;
                noPai.filhos[1] = filhoDireitaPai;
            }
            else
            {   printf("ELSE\n");
                i++;
                printf("noPai.codigos[%d]=%d  =  codigos[2] = %d\n", i, noPai.codigos[i],  codigos[2]);
                printf("noPai.posicoes[%d]=%d  =  posicoes[2] = %d\n",i, noPai.posicoes[i],  posicoes[2]);
                printf("noPai.filhos[%d]=%d  =  enderecoNo= %d\n",i, noPai.filhos[i], enderecoNo);
                printf("noPai.filhos[%d]=%d  =  filhoDireitaPai= %d\n", i+1, noPai.filhos[i+1],  filhoDireitaPai);
                noPai.codigos[i] = codigos[2];
                noPai.posicoes[i] = posicoes[2];
                noPai.filhos[i] = enderecoNo;
                noPai.filhos[i+1] = filhoDireitaPai;
            }
            
            noPai.qtd++;
            printf("noPai.qtd++ = %d\n", noPai.qtd );
            fseek(indice, enderecoPai, SEEK_SET);
            fwrite(&noPai, sizeof(struct nob), 1, indice);
        }
    }
    fclose(indice);
}


void indexar(int codigo, int posicaoCursor, int endRaiz)
{   char achou = 0;
    char explodiu = 0;
    FILE *indice = fopen("indice.ind", "r+");
    inicializaNo();
    printf("CONTROLE = %d\n", CONTROLE);
    //Posiciona na Raiz
    fseek(indice, endRaiz, SEEK_SET);  
    //Carrega uma estrutura
    fread(&no, sizeof(struct nob), 1, indice);

    int i;
    printf("EnderecoRaiz = %d\n", endRaiz );
    //printf("%d - %d\n", codigo, no.qtd);
    for (i = 0; i < no.qtd; i++)
    {   //organiza
        if (no.codigos[i] > codigo)
        {   printf("no.codigos[%d]=%d > codigo=%d\n", i, no.codigos[i], codigo );

            if (no.filhos[i] != -1)
            {   printf("no.filhos[i] != -1\n");
                push(pilha, endRaiz);
                printf("EMPLILHA = %d\n",endRaiz );

                printf("indexar(codigo, posicaoCursor, no.filhos[i]);\n");
                printf("indexar(%d, %d, %d);\n",codigo, posicaoCursor, no.filhos[i] );
                indexar(codigo, posicaoCursor, no.filhos[i]);
            }
            else
            {   printf("ELSE\n");
                if (no.qtd == CONTROLE)
                {   //Explode
                    printf("no.qtd==CONTROLE\n");
                    explodiu = 1;
                    printf("\n\nEXPLODIU!\n");
                    
                    printf("explodir(codigo, posicaoCursor, -1, endRaiz, pop2);\n");
                    printf("explodir(%d, %d, %d, %d, %d);\n", codigo, posicaoCursor, -1, endRaiz, 9999 );
                    printf("Codigo = %d\n", codigo );
                    printf("posicaoCursor = %d\n", posicaoCursor );
                    printf("endRaiz = %d\n", endRaiz );
                    int pop2 = pop(pilha);
                    printf("PilhaPO = %d\n", pop2 );
                    explodir(codigo, posicaoCursor, -1, endRaiz, pop2);
                }
                else
                {   printf("no.qtd!=CONTROLE\n" );
                    for (int j = CONTROLE-1; j>i; j--)
                    {   //Organiza de traz pra frente, se tem espaco
                        printf("no.codigos[%d]=%d = no.codigos[%d]=%d\n",  j, no.codigos[j], j-1,  no.codigos[j-1] );
                        printf("no.posicoes[%d]=%d = no.posicoes[%d]=%d\n",  j, no.posicoes[j], j-1,  no.posicoes[j-1] );
                        printf("no.filhos[%d]=%d = no.filhos[%d]=%d\n",  j+1, no.filhos[j], j,  no.filhos[j] );
                        printf("no.filhos[%d]=%d = no.filhos[%d]=%d\n",  j, no.filhos[j], j-1,  no.filhos[j-1] );
                        no.codigos[j] = no.codigos[j-1];
                        no.posicoes[j] = no.posicoes[j-1];
                        no.filhos[j+1] = no.filhos[j];
                        no.filhos[j] = no.filhos[j-1];
                    }
                    //Depois de organizar, insere na posicao
                    printf("no.codigos[%d] = %d\n", i, codigo);
                    printf("no.posicoes[%d] = %d\n", i, posicaoCursor);
                    no.codigos[i] = codigo;
                    no.posicoes[i] = posicaoCursor;
                    printf("achou lugar %d\n", codigo);
                    achou = 1;
                }
            }
            break;
        }
    }

    printf("SAIU DO FOR\n");
    if (i == no.qtd && !explodiu)
    {   if (no.filhos[i] != -1)
        {   printf("NO FILHO != -1\n");
            push(pilha, endRaiz);
            printf("Epilha=%d\n", endRaiz);
            printf("indexar(codigo, posicaoCursor, no.filhos[i]);\n");
            printf("indexar(%d, %d, %d);\n",codigo, posicaoCursor, no.filhos[i] );
            indexar(codigo, posicaoCursor, no.filhos[i]);
        }
        else
        {   if (i == CONTROLE)
            {   printf("i==CONTROLE\n");
                printf("\n\nEXPLODIUCONTROLE!\n");
                
                printf("explodir(codigo, posicaoCursor, -1, endRaiz, pop3);\n");
                printf("explodir(%d, %d, %d, %d, %d);\n", codigo, posicaoCursor, -1, endRaiz, 9999 );
                printf("codigo = %d\n",codigo );
                printf("posicaoCursor = %d\n",posicaoCursor );
                printf("endRaiz = %d\n",endRaiz );
                
                int pop3 = pop(pilha);
                printf("POP = %d\n",pop3 );

                explodir(codigo, posicaoCursor, -1, endRaiz, pop3);
            }
            else
            {   printf("i!=CONTROLE\n");
                printf("no.codigos[%d] = %d\n", no.qtd, codigo);
                printf("no.posicoes[%d] = %d\n", no.qtd, posicaoCursor);
                no.codigos[no.qtd] = codigo;
                no.posicoes[no.qtd] = posicaoCursor;
                printf("achou lugar %d\n", codigo);
                achou = 1;
            }
        }
    }
    if (achou)
    {   printf("codigo: %d - qtd: %d para %d\n", codigo, no.qtd, no.qtd+1);
        no.qtd++;
        fseek(indice, endRaiz, SEEK_SET);
        fwrite(&no, sizeof(struct nob), 1, indice);

    }
    fclose(indice);
    //printf("--%d--\n", achou);
}


int main()
{

    FILE *arquivo;
    if ((arquivo = fopen("arq.csv", "rt")) == NULL)
    {   printf("o arquivo especificado não existe\n");
        return 2;
    }

    char linha[1001];
    int codigo;
    int posicaoCursor;

    inicializaNo();

    posicaoCursor = (int) ftell(arquivo);
    while ((fgets(linha, 1000, arquivo)) != NULL)
    {   sscanf(linha, "%d", &codigo);
        FILE *indice = fopen("indice.ind", "r+");
        int endRaiz;
        
        if (indice == NULL)
        {   indice = fopen("indice.ind", "w+");
            endRaiz = CONTROLE;
            fwrite(&endRaiz, sizeof(int), 1, indice);
        }
        else
        {   //Atualiza Raiz da Arv p endRaiz
            fread(&endRaiz, sizeof(int), 1, indice);
        }

        fclose(indice);
        inicializar(pilha);
        indexar(codigo, posicaoCursor, endRaiz);
        posicaoCursor = (int) ftell(arquivo);
    }
    fclose(arquivo);
}
