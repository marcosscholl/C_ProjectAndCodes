#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MODO 2
const int CONTROLE = MODO *2;

struct nob
{   char qtd;
    int codigos[CONTROLE];
    int posicoes[CONTROLE];
    int filhos[CONTROLE+1];
} no;

void inicializaNo()
{   no.qtd=0;
    for (int i=0; i<CONTROLE+1; i++)
    {   no.filhos[i]=-1;
        if (i<CONTROLE)
        {   no.codigos[i]=0;
            no.posicoes[i]=-1;
        }
    }
}

int procura(int codigo, int posicao)
{   FILE *index = fopen("indice.ind", "r");
    fseek(index, posicao, SEEK_SET);
    fread(&no, sizeof(struct nob), 1, index);
    int i;
    for (i=0; i<no.qtd; i++)
    {   if (no.codigos[i] >= codigo) break;
    }
    if (i != no.qtd && no.codigos[i] == codigo)
    {   if (no.posicoes[i] < 0) return -1;
        return posicao;
    }
    if (no.filhos[i] == -1) return -1;
    return procura(codigo, no.filhos[i]);
}

int main()
{   
    FILE *arquivo, *index;
    if ((arquivo = fopen("arq.csv", "r+")) == NULL)
    {   printf("ERROR: O Arquivo não existe!\n");
        return 0;
    } 
    if ((index = fopen("indice.ind", "r+")) == NULL)
    {   printf("ERROR: O arquivo não existe!\n");
        return 0;
    }
    
    int endereco, codigo, posicao;
    fseek(index, 0, SEEK_SET);
    fread(&endereco, sizeof(int), 1, index);
    
    printf("\nBuscar Codigo: ");
    scanf("%d", &codigo);
    
    inicializaNo();
    
    
    posicao = procura(codigo, endereco);
    if (posicao < 0) printf("ERROR: Codigo não encontrado!\n");
    else
    {   int i;

        char novaLinha[85] = "", nome[50], sexo[2], dataNasc[10], sal[14], cod[7];
        sprintf(cod, "%d", codigo);
        for (i=0; no.codigos[i]!=codigo; i++);
        printf("Editando Pessoa:\n");
        
        strcat(novaLinha, cod);
        strcat(novaLinha, ";");
        printf("Digite o novo Nome:\n");
        scanf("%s", nome);
        strcat(novaLinha, nome);
        strcat(novaLinha, ";");
        printf("Digite o novo Sexo:\n");
        scanf("%s", sexo);
        strcat(novaLinha, sexo);
        strcat(novaLinha, ";");
        printf("Digite a nova data de Nascimento:\n");
        scanf("%s", dataNasc);
        strcat(novaLinha, dataNasc);
        strcat(novaLinha, ";");
        printf("Digite o novo Salario:\n");
        scanf("%s", sal);
        strcat(novaLinha, sal);
        strcat(novaLinha, "\n");
        fseek(arquivo, 0, SEEK_END);
        int novoEndereco = ftell(arquivo);
        fwrite(novaLinha, sizeof(char), strlen(novaLinha), arquivo);
        
        no.posicoes[i] = novoEndereco;
        fseek(index, posicao, SEEK_SET);
        fwrite(&no, sizeof(struct nob), 1, index);
        printf("\nEditado com Sucesso!\n\n");

    }
    fclose(index);
    fclose(arquivo);
}
