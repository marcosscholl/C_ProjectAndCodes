#include <stdio.h>
#include <stdlib.h>

//#define CONTROLE 2
#define MODO 2
const int CONTROLE = MODO *2;
//const int MODO = CONTROLE/2;
/*
Modo 5
3 24 36 60 64 [78] 79 102 109 125 131 

Modo 4
3 24 36 60 [78] 79 102 125 131

Modo 3
3 24 36 [78] 79 102 131

Modo 2
3 24 [78] 79 102 

3 24 [78] 79 102 103

*/
struct nob
{   char qtd;
    int codigos[CONTROLE];
    int posicoes[CONTROLE];
    int filhos[CONTROLE+1];
} no, noMaior, noPai;

struct Pilha
{   int endereco;
    struct Pilha *prox;
} *pilha = NULL;

void push(struct Pilha *&p, int end)
{   struct Pilha *novo = new(struct Pilha);
    novo->prox = p;
    novo->endereco = end;
    p = novo;
}

int pop(struct Pilha *&p)
{   if (p==NULL) return -1;
    int end = p->endereco;
    struct Pilha *i = p;
    p = p->prox;
    delete(i);
    return end;
}

void inicializar(struct Pilha *&p)
{   struct Pilha *t, *i = p;
    while (i != NULL)
    {   t = i;
        i = i->prox;
        delete(t);
    }
    p = NULL;
}

void inicializaNo()
{   no.qtd = 0;
    for (int i = 0; i < CONTROLE+1; i++)
    {   no.filhos[i] = -1;
        if (i < CONTROLE)
        {   no.codigos[i] = 0;
            no.posicoes[i] = -1;
        }
    }
}

void inicializaNoMaior()
{   noMaior.qtd = 0;
    for (int i = 0; i < CONTROLE+1; i++)
    {   noMaior.filhos[i] = -1;
        if (i < CONTROLE)
        {   noMaior.codigos[i] = 0;
            noMaior.posicoes[i] = -1;
        }
    }
}

void inicializaNoPai()
{   noPai.qtd=0;
    for (int i = 0; i < CONTROLE+1; i++)
    {   noPai.filhos[i] = -1;
        if (i < CONTROLE)
        {   noPai.codigos[i] = 0;
            noPai.posicoes[i] = -1;
        }
    }
}


//fseek()       Procura por um byte específico (Começo do arquivo   SEEK_SET    0)
//fread()       le um bloco de dados
//fwrite        escreve um bloco de dados
//fgets()       são funções para ler e escrever strings.
//ftell         retorna a posição corrente de leitura ou escrita no arquivo (em bytes)
void explodir(int codigo, int posicao, int filhoD, int enderecoNo, int enderecoPai)
{   //filhoD, posicao do maior novo nó maior a direira do que explodiu
    FILE *indice = fopen("indice.ind", "r+");
    fseek(indice, enderecoNo, SEEK_SET);
    fread(&no, sizeof(struct nob), 1, indice);
    int codigos[CONTROLE+1];
    int posicoes[CONTROLE+1];
    int filhos[CONTROLE+2];

    //Carrega o nó pro vetor
    for (int i=0; i<CONTROLE; i++)
    {   codigos[i] = no.codigos[i];
        posicoes[i] = no.posicoes[i];
        filhos[i] = no.filhos[i];
    }
    //posiciona o ultimo filho do nó no vetor
    filhos[CONTROLE] = no.filhos[CONTROLE];
    
    //Testa se precisa ordenar o nó pra quem subiu
    int i;
    for (i=0; i<CONTROLE+1; i++)
    {   if (i==CONTROLE)
        {   i++;
            break;
        }
        if (no.codigos[i] > codigo) break;
    }
    //Temos um vetor de CONTROLE+1 Posicoes ordenados
    if (i==CONTROLE+1)
    {   codigos[CONTROLE] = codigo;
        posicoes[CONTROLE] = posicao;
        filhos[CONTROLE+1] = filhoD;
    }
    else
    {   for (int j=CONTROLE; j>i; j--)
        {   codigos[j] = codigos[j-1];
            posicoes[j] = posicoes[j-1];
        }
        for (int j=CONTROLE; j>i; j--)
        {   filhos[j+1] = filhos[j];
        }
        filhos[i+1] = filhoD;
        codigos[i] = codigo;
        posicoes[i] = posicao;
    }
    
    //Organiza a Explosão
    inicializaNoMaior();
    noMaior.qtd = MODO;
    
    for (int k = 0,c = MODO+1; k < MODO; k++, c++)
    {   noMaior.codigos[k] = codigos[c];
        noMaior.posicoes[k] = posicoes[c];
        noMaior.filhos[k] = filhos[c];
    }
    noMaior.filhos[MODO] = filhos[CONTROLE+1];
     /*
         [1][2][3][4] 5
       [1][2] [3] [4][5] 6
         3     2    3


        [0][1][2][3][4][5][6][7][8][9]
      [0][1][2][3][4] [5] [6][7][8][9][10] 12
             6         2         6
    */

    inicializaNo();
    no.qtd = MODO;
    
    for (int k = 0; k < MODO; k++)
    {   no.codigos[k] = codigos[k];
        no.posicoes[k] = posicoes[k];
        no.filhos[k] = filhos[k];        
    }
    no.filhos[MODO] = filhos[MODO];
   
    //carrega no arquivo 
    fseek(indice, enderecoNo, SEEK_SET);
    fwrite(&no, sizeof(struct nob), 1, indice);
    fseek(indice, 0, SEEK_END);
    int filhoDireitaPai = (int) ftell(indice);
    //novo Pai/Raiz
    fwrite(&noMaior, sizeof(struct nob), 1, indice);
    
    if (enderecoPai == -1)
    {   //Cria novo Nó para Inicio da Arvore, novaRaiz
        inicializaNoPai();
        noPai.qtd = 1;
        noPai.codigos[0] = codigos[MODO];
        noPai.posicoes[0] = posicoes[MODO];
        //filho Menor
        noPai.filhos[0] = enderecoNo;
        // Filho Maior
        noPai.filhos[1] = filhoDireitaPai;
        
        fseek(indice, 0, SEEK_END);
        int novaRaiz = ftell(indice);
        fwrite(&noPai, sizeof(struct nob), 1, indice);
        fseek(indice, 0, SEEK_SET);
        //Atualiza a Raiz no Arquivo
        fwrite(&novaRaiz, sizeof(int), 1, indice);
    }
    else
    {   fseek(indice, enderecoPai, SEEK_SET);
        //Carrega o Blogo Pai
        fread(&noPai, sizeof(struct nob), 1, indice);
        //Se o pai ja tiver CONTROLE nro de codigos, explode de novo
        if (noPai.qtd == CONTROLE)
        {   //Explode o Meio do vetor, por ser a nova raiz.
            explodir(codigos[MODO], posicoes[MODO], filhoDireitaPai, enderecoPai, pop(pilha));
        }
        else
        {   int i;
            for (i=noPai.qtd-1; i>=0; i--)
            {   if (noPai.codigos[i] > codigos[MODO])
                {   noPai.codigos[i+1] = noPai.codigos[i];
                    noPai.posicoes[i+1] = noPai.posicoes[i];
                    noPai.filhos[i+MODO] = noPai.filhos[i+1];
                    noPai.filhos[i+1] = noPai.filhos[i];
                }
                else break;
            }
            if (i==-1)
            {   noPai.codigos[0] = codigos[MODO];
                noPai.posicoes[0] = posicoes[MODO];
                noPai.filhos[0] = enderecoNo;
                noPai.filhos[1] = filhoDireitaPai;
            }
            else
            {   i++;
                noPai.codigos[i] = codigos[MODO];
                noPai.posicoes[i] = posicoes[MODO];
                noPai.filhos[i] = enderecoNo;
                noPai.filhos[i+1] = filhoDireitaPai;
            }
            
            noPai.qtd++;
            //grava NoPai
            fseek(indice, enderecoPai, SEEK_SET);
            fwrite(&noPai, sizeof(struct nob), 1, indice);
        }
    }
    fclose(indice);
}


void indexar(int codigo, int posicaoCursor, int endRaiz)
{   char inseriuCodigo = 0;
    char explodiu = 0;
    FILE *indice = fopen("indice.ind", "r+");
    inicializaNo();
    //Posiciona na Raiz
    fseek(indice, endRaiz, SEEK_SET);  
    //Carrega uma estrutura
    fread(&no, sizeof(struct nob), 1, indice);

    int i;
    for (i = 0; i < no.qtd; i++)
    {   //organiza
        if (no.codigos[i] > codigo)
        {   if (no.filhos[i] != -1)
            {  //empilhaRaiz e indexa
                push(pilha, endRaiz);
                indexar(codigo, posicaoCursor, no.filhos[i]);
            }
            else
            {   if (no.qtd == CONTROLE)
                {   //Explode
                    explodiu = 1;                    
                    int popMODO = pop(pilha);
                    explodir(codigo, posicaoCursor, -1, endRaiz, popMODO);
                }
                else
                {   for (int j = CONTROLE-1; j>i; j--)
                    {   //Organiza de traz pra frente, se tem espaco
                        no.codigos[j] = no.codigos[j-1];
                        no.posicoes[j] = no.posicoes[j-1];
                        no.filhos[j+1] = no.filhos[j];
                        no.filhos[j] = no.filhos[j-1];
                    }
                    //Depois de organizar, insere na posicao
                    no.codigos[i] = codigo;
                    no.posicoes[i] = posicaoCursor;
                    inseriuCodigo = 1;
                }
            }
            break;
        }
    }
    if (i == no.qtd && !explodiu)
    {   if (no.filhos[i] != -1)
        {   push(pilha, endRaiz);
            indexar(codigo, posicaoCursor, no.filhos[i]);
        }
        else
        {   if (i == CONTROLE)
            {   explodir(codigo, posicaoCursor, -1, endRaiz, pop(pilha));
            }
            else
            {   no.codigos[no.qtd] = codigo;
                no.posicoes[no.qtd] = posicaoCursor;
                inseriuCodigo = 1;
            }
        }
    }
    if (inseriuCodigo)
    {   //Se conseguiu inserir, Grava o no
        no.qtd++;
        fseek(indice, endRaiz, SEEK_SET);
        fwrite(&no, sizeof(struct nob), 1, indice);
    }
    fclose(indice);
}


int main()
{   FILE *arquivo;
    if ((arquivo = fopen("arq.csv", "rt")) == NULL)
    {   printf("ERROR: O arquivo não existe!\n");
        return 0;
    }

    char linha[85];
    int codigo, posicaoCursor;

    inicializaNo();
    posicaoCursor = (int) ftell(arquivo);
    while ((fgets(linha, 85, arquivo)) != NULL)
    {   sscanf(linha, "%d", &codigo);
        FILE *indice = fopen("indice.ind", "r+");
        int endRaiz;
        
        if (indice == NULL)
        {   indice = fopen("indice.ind", "w+");
            endRaiz = CONTROLE;
            fwrite(&endRaiz, sizeof(int), 1, indice);
        }
        else
        {   //Atualiza Raiz da Arv p endRaiz
            fread(&endRaiz, sizeof(int), 1, indice);
        }

        fclose(indice);
        inicializar(pilha);
        indexar(codigo, posicaoCursor, endRaiz);
        posicaoCursor = (int) ftell(arquivo);
    }
    fclose(arquivo);
    printf("\nArquivo Indexado com Sucesso!\nConsulte o novo Aquivo ('indice.ind').\n");

}