void remove(struct lde *&l)
{	struct lde *p, *t, *ant;
	ant = NULL;
	int r;
	int i;
	//Eu não queria fazer isso, mas não teve jeito. 
	for (i = 0; i < 5; i++)
	{
		for (p = l; p != NULL && p->proximo != NULL;)
		{	if (p -> informacao == p->proximo->informacao)
			{	r = p->informacao;
				while(p->informacao == r)
				{	t = p;
					if (p->proximo != NULL)
					{	p = p->proximo;
						delete(t);
					} 
					else 
					{	p = p->proximo;
						break;
					}		
				}	
				
				//Pra Funcionar De Boa. 	
				if (p == NULL && ant == NULL)	l = p;
				else if (p == NULL && ant != NULL)
				{	l = ant;
					ant->proximo = p;
				}
				else if (ant == NULL && p != NULL)	l = p;
				else
				{	if (p-> anterior == NULL) l = p->proximo;
					ant->proximo = p;
					if (p-> anterior == NULL) l = p->proximo;
				}			
			}
			else 
			{	ant = p;
				p = p-> proximo;	
			}
		}
	}
}